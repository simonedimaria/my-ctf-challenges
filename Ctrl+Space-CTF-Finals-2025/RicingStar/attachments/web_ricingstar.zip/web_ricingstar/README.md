# RicingStar
- you don't need to read any of the app/* files to solve the challenge
- `curl -X POST http://0.0.0.0:80/bot/visit -H "content-type: application/json" -d '{"url": "https://example.com"}'` to trigger the bot visit
- flag format is `space\{[a-z0-9_?]+\}`
- https://youtu.be/s1iBYOEnKhM
