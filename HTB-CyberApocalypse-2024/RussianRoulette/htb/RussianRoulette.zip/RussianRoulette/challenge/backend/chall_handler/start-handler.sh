#!/bin/bash

exec python3 -u /home/ctf/backend/handler.py
